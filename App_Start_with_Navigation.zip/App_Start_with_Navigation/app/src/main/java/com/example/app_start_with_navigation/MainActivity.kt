 package com.example.app_start_with_navigation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.*
import kotlinx.android.synthetic.main.activity_main.*


 class MainActivity : AppCompatActivity() {
    private lateinit var  navController: NavController
    private lateinit var  appBarConfiguration: AppBarConfiguration


    //creating menu
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.findNavController()


        //bottom menu and side panel
        appBarConfiguration = AppBarConfiguration(
            setOf(R.id.homeFragment,R.id.searchFragment),
            drawer_layout
        )

        setSupportActionBar(toolbar)
        setupActionBarWithNavController(navController, appBarConfiguration)

        //set up button menu
        bottom_nav.setupWithNavController(navController)
        //Setup side menu
        nav_view.setupWithNavController(navController)
    }

     //activiting menus
     override fun onCreateOptionsMenu(menu: Menu?): Boolean {
         menuInflater.inflate(R.menu.options,menu)
         return true
     }

     //
     override fun onOptionsItemSelected(item: MenuItem): Boolean {
         //if true it will go the Terms & Conditions
         return if(item.itemId == R.id.termsAndConditions){
             val action = NavGraphDirections.actionGlobalTermsFragment()
             navController.navigate(action)
             true
         }
         else{
             item.onNavDestinationSelected(navController)
                     || super.onOptionsItemSelected(item)
         }
     }


     override fun onSupportNavigateUp(): Boolean {
         return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()

     }


}