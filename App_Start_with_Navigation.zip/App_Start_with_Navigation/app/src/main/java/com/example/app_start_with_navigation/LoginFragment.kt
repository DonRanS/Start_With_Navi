package com.example.app_start_with_navigation

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_welcome.*

class LoginFragment : Fragment(R.layout.fragment_login) {

    //connecting the pointer into the fragment
    private val args: LoginFragmentArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        //get the username from the args
        val usernameDeepLink = args.username
        edit_username.setText(usernameDeepLink)


        confirm_button.setOnClickListener {

            //gets the input from user into a variables.
            val username = edit_username.text.toString()
            val password = edit_password.text.toString()

            //sends the variables to the next page.
            val action = LoginFragmentDirections.actionLoginFragmentToWelcomeFragment(username, password)
            findNavController().navigate(action)

        }
    }

}