package com.example.app_start_with_navigation

import androidx.fragment.app.Fragment

class TermsFragment : Fragment(R.layout.fragment_terms) {


}